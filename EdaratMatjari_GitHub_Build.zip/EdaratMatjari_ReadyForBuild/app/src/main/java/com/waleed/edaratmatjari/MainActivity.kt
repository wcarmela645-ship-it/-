package com.waleed.edaratmatjari

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

data class Product(var code:String, var name:String, var cost:Double, var price:Double, var qty:Int)

class MainActivity : AppCompatActivity() {
    private val products = mutableListOf<Product>()
    private val prefs by lazy { getSharedPreferences("shop_data", MODE_PRIVATE) }
    private lateinit var body: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()
    private var scannerOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL; setPadding(18,18,18,18) }
        root.setBackgroundColor(0xFFF3F6F3.toInt())
        val title = TextView(this).apply { text="إدارة متجري"; textSize=25f; setTextColor(0xFF14532D.toInt()); setPadding(0,8,0,18) }
        root.addView(title)
        val tabs = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("المنتجات","مسح باركود","التقارير").forEachIndexed { i, label ->
            val b=Button(this).apply { text=label; textSize=12f; setOnClickListener { when(i){0->showProducts();1->showScanner();2->showReports()} } }
            tabs.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        }
        root.addView(tabs)
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,15,0,0) }
        root.addView(body, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        showProducts()
    }

    private fun field(hint:String, value:String=""): EditText = EditText(this).apply {
        this.hint=hint; setText(value); textSize=16f
    }
    private fun button(text:String, action:()->Unit)=Button(this).apply { this.text=text; setOnClickListener { action() } }
    private fun reset(title:String) { body.removeAllViews(); body.addView(TextView(this).apply { text=title; textSize=19f; setTextColor(0xFF14532D.toInt()); setPadding(0,0,0,10) }) }

    private fun showProducts() {
        reset("إضافة منتج")
        val name=field("اسم المنتج"); val code=field("رقم الباركود"); val cost=field("سعر الشراء بالجنيه"); val price=field("سعر البيع بالجنيه"); val qty=field("الكمية")
        listOf(name,code,cost,price,qty).forEach { body.addView(it) }
        body.addView(button("حفظ المنتج") {
            val c=code.text.toString().trim(); val n=name.text.toString().trim()
            val co=cost.text.toString().toDoubleOrNull(); val pr=price.text.toString().toDoubleOrNull(); val q=qty.text.toString().toIntOrNull()
            if(c.isBlank()||n.isBlank()||co==null||pr==null||q==null||co<0||pr<0||q<0) { toast("أكمل بيانات المنتج بصورة صحيحة"); return@button }
            if(products.any { it.code==c }) { toast("الباركود مسجل مسبقاً"); return@button }
            products.add(Product(c,n,co,pr,q)); saveData(); toast("تم حفظ المنتج"); showProducts()
        })
        body.addView(TextView(this).apply { text="المنتجات المسجلة"; textSize=18f; setPadding(0,18,0,8) })
        products.forEach { p ->
            body.addView(TextView(this).apply {
                text="${p.name}\nباركود: ${p.code}\nشراء: ${p.cost} | بيع: ${p.price} | ربح القطعة: ${p.price-p.cost}\nالمخزون: ${p.qty}"
                textSize=15f; setPadding(10,10,10,10); setBackgroundColor(0xFFFFFFFF.toInt())
            })
        }
    }

    private fun showScanner() {
        reset("مسح الباركود بالكاميرا")
        val preview=PreviewView(this)
        body.addView(preview, LinearLayout.LayoutParams(-1,0,1f))
        val status=TextView(this).apply { text="وجّه الكاميرا إلى الباركود"; textSize=16f; setPadding(0,12,0,12) }
        body.addView(status)
        val manual=field("أدخل رقم الباركود يدوياً"); body.addView(manual)
        body.addView(button("بحث") { showProductResult(manual.text.toString(), status) })
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera(preview,status)
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 44)
        preview.tag=status
    }

    private fun startCamera(preview:PreviewView,status:TextView) {
        val future=ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider=future.get()
            val pv=Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            val barcodeScanner=BarcodeScanning.getClient()
            analysis.setAnalyzer(executor) { proxy ->
                val media=proxy.image
                if(media==null){proxy.close();return@setAnalyzer}
                val image=InputImage.fromMediaImage(media,proxy.imageInfo.rotationDegrees)
                barcodeScanner.process(image).addOnSuccessListener { codes ->
                    val raw=codes.firstOrNull()?.rawValue
                    if(!raw.isNullOrBlank()) runOnUiThread {
                        status.text="تمت قراءة: $raw"
                        showProductResult(raw,status)
                    }
                }.addOnCompleteListener { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,pv,analysis)
            } catch(e:Exception) { runOnUiThread { status.text="تعذر تشغيل الكاميرا: ${e.message}" } }
        },ContextCompat.getMainExecutor(this))
    }

    private fun showProductResult(code:String,status:TextView) {
        val p=products.firstOrNull { it.code==code.trim() }
        status.text=if(p==null) "لا يوجد منتج بهذا الباركود" else
            "${p.name}\nسعر الشراء: ${p.cost} جنيه\nسعر البيع: ${p.price} جنيه\nربح القطعة: ${p.price-p.cost} جنيه\nالكمية المتبقية: ${p.qty}"
    }

    private fun showReports() {
        reset("التقارير")
        body.addView(TextView(this).apply {
            text="عدد المنتجات: ${products.size}\nقيمة المخزون بسعر الشراء: ${products.sumOf { it.cost*it.qty }} جنيه\nقيمة المخزون بسعر البيع: ${products.sumOf { it.price*it.qty }} جنيه"
            textSize=17f
        })
    }

    private fun saveData() {
        val arr=JSONArray()
        products.forEach { p -> arr.put(JSONObject().put("code",p.code).put("name",p.name).put("cost",p.cost).put("price",p.price).put("qty",p.qty)) }
        prefs.edit().putString("products",arr.toString()).apply()
    }
    private fun loadData() {
        try {
            val arr=JSONArray(prefs.getString("products","[]"))
            for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); products.add(Product(o.getString("code"),o.getString("name"),o.getDouble("cost"),o.getDouble("price"),o.getInt("qty"))) }
        } catch (_:Exception) {}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()

    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==44 && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) showScanner()
        else if(requestCode==44) toast("يجب السماح باستخدام الكاميرا لمسح الباركود")
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
